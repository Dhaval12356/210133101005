function alertfunex()
{alert('external script')}
function confirmfunex()
{confirm('external script')}
function promptfunex()
{prompt('external script')}